# FAQ

(This FAQ is not a legal document... always check with a lawyer!).

> SathyaServer is licensed under the GNU Lesser General Public License 3.0 (LGPL 3.0).

This basically boils down to:
* "Forks" or works derived directly from SathyaServer code must be licensed and released under the LGPL 3.0.
* Code licensed under the LGPL must have it's source code available for download.
* You free to distribute, modify, and even sell SathyaServer, as long as you follow the LGPL.

SathyaServer is licensed under the LGPL so that it will always remain free (as in freedom) and trustable.

## Can I write a proprietary or non-GPL modules for SathyaServer?
**Yes**. While we highly recommend releasing your work under a copyleft license like the GPL, SathyaServer was licensed 
under the LGPL in order to allow proprietary or non-GPL licensed modules.